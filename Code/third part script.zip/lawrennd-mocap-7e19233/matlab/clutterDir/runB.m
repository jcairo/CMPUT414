bvhModel('b', 1);
bvhModel('b', 2);