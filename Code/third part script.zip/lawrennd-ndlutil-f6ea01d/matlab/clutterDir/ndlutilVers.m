function [vers, depend] = ndlutilVers

% NDLUTILPATH Brings dependent toolboxes into the path.

vers = 0.131;
if nargout > 2
  depend = [];
end
