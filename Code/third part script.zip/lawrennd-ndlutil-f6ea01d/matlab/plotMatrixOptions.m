function options = plotMatrixOptions

% PLOTMATRIXOPTIONS Default options for plot matrix.

% NDLUTIL

options.zoom.on = false;
options.zoom.row = [];
options.zoom.col = [];
options.highlight.on = false;
options.highlight.row = [];
options.highlight.col = [];
options.colormap = []; 
